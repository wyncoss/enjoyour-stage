import React, { useState, useEffect } from 'react';

export const Carousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [message] = useState([
    'La gente que realmente aprecia a los animales siempre pregunta sus nombres',
    'Los ojos de un animal tienen el poder de hablar un gran lenguaje',
    'Los animales no son propiedades o cosas, sino organismos vivientes, sujetos de una vida, que merecen nuestra compasión, respeto, amistad y apoyo',
    'El corazón de un animal late al ritmo de la naturaleza.',
    'La presencia de un animal llena de alegría cualquier espacio.',
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prevIndex => (prevIndex + 1) % message.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [message.length]);

  return (
    <>
      <header>
        {/* Contenedor del título y el logotipo */}
        <div id="titulo" onClick={() => linkTo(null, null)}>
          <div id="logoContainer" className="logo--flex">
            <img id="logo" src="/src/assets/img/logo.png" alt="" />
            <svg
              width="100"
              height="10"
              viewBox="0 0 354.99999999999994 42.500511538101215"
              className="css-1j8o68f"
            >
              {/* Contenido del SVG */}
            </svg>
          </div>
        </div>
        {/* Menú de navegación */}
        <div className="menu">
          {/* Botón de menú responsive */}
          <div className="sandwich-menu" onClick={() => toggleMenu()}>
            &#9776;
          </div>
          {/* Sección de adopciones (condicional) */}
          <div className="menu-item">
            Adopciones
            <ul className="submenu">
              <li
                onClick={() =>
                  linkTo('usuario', 'adopciones', 'adoptar/TODO/0/0')
                }
              >
                Adoptar
              </li>
              <li onClick={() => linkTo('usuario', 'adopciones', 'dar')}>
                Dar en adopción
              </li>
            </ul>
          </div>
          {/* Sección de Lugares */}
          <div className="menu-item">
            Lugares
            <ul className="submenu">
              <li>
                <a
                  href="https://www.google.com/maps/search/pet+friendly/"
                  target="_blank"
                >
                  Pet Friendly
                </a>
              </li>
              <li onClick={() => linkTo('Pronto-Implementado')}>
                Localización
              </li>
            </ul>
          </div>
          {/* Sección de Negocios */}
          <div className="menu-item">
            Negocios
            <ul className="submenu">
              <li onClick={() => linkTo('vender', null)}>Vender</li>
              <li>
                Comprar
                <ul className="shop--submenu">
                  <li onClick={() => linkTo('productos', 'todo', '0')}>Todo</li>
                  <li onClick={() => linkTo('productos', 'juguetes', '0')}>
                    Juguetes
                  </li>
                  <li onClick={() => linkTo('productos', 'alimentos', '0')}>
                    Alimentos
                  </li>
                  <li onClick={() => linkTo('productos', 'accesorios', '0')}>
                    Accesorios
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          {/* Sección de Servicios */}
          <div className="menu-item">
            Servicios
            <ul className="submenu">
              <li>
                <a href="https://Digipets.com.co" target="_blank">
                  Veterinaria
                </a>
              </li>
              <li>
                Entrenamiento
                <ul className="vet--submenu">
                  <li onClick={() => linkTo('entrenamiento', 'ensenar')}>
                    Enseñar
                  </li>
                  <li
                    className="menuc"
                    onClick={() => linkTo('entrenamiento', 'aprender')}
                  >
                    Aprender
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          {/* Espacio adicional en el menú */}
          <div className="menu-item">
            <span></span>
            <ul className="submenu">
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
        {/* Script para la funcionalidad del menú */}
        <script src="/resources/js/header.js"></script>
      </header>

      <main>
        <section className="container" id="carousel-container">
          <div id="carousel">
            <div id="carousel-text">
              <h1>{message[currentIndex]}</h1>
            </div>
            {message.map((msg, index) => (
              <div
                key={index}
                className={`img-carousel ${
                  index !== currentIndex ? 'hide' : ''
                }`}
              >
                <img
                  src={`/src/assets/img/00${index + 1}.jpg`}
                  alt={`imagen ${index + 1} del carousel`}
                />
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};
