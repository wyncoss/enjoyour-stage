import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
export const LoginModal = () => {
  const [correo, setCorreo] = useState('');
  const [contrasenia, setContrasenia] = useState('');
  const navigate = useNavigate(); // Utiliza useNavigate para obtener la función de navegación

  const handleSubmit = async event => {
    event.preventDefault(); // Evita que el formulario se envíe automáticamente

    try {
      const response = await fetch(
        'https://apienjoy-production.up.railway.app/log-in',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ correo, contrasenia }),
        }
      );

      const data = await response.json();
      console.log(data.correcto); // Puedes hacer algo con la respuesta del servidor aquí
      if (data.correcto === true) {
        console.log('se inicio sesion correctamente');
        alert('se inicio sesion correctamente');
        navigate('/loged');
      } else {
        console.log('no inicio sesion correctamente \n' + data.error);
        alert(data.error);
      }
    } catch (error) {
      console.error('Error al enviar la solicitud:', error);
    }
  };

  return (
    <>
      <section className="sign__flex container" style={{ marginTop: '8rem' }}>
        <form className="form_loginn" onSubmit={handleSubmit}>
          <h1>Inicia Sesión</h1>
          <input
            type="email"
            name="correo"
            placeholder="Correo"
            autoComplete="off"
            required
            value={correo}
            onChange={e => setCorreo(e.target.value)}
          />
          <input
            type="password"
            name="contrasenia"
            placeholder="Contraseña"
            autoComplete="off"
            required
            value={contrasenia}
            onChange={e => setContrasenia(e.target.value)}
          />
          <button type="submit" className="Ingresar" name="enviar">
            Iniciar Sesión
          </button>
          <button className="other-button">¿Olvidaste tu contraseña?</button>
        </form>
      </section>
    </>
  );
};
