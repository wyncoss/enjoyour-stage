import { Link } from 'react-router-dom';

export const Categories = () => {
  return (
    <>
      <section className="wrapper size5">
        {/* <!-- Sección "Pet Friendly" --> */}
        <div className="petfriendly__grid container size">
          <div className="petfriendly__content">
            <h2>Pet Friendly</h2>
            <p>
              Pet Friendly significa que todo negocio o establecimiento de
              comercio que afirme sentirse identificado con esta filosofía
              permita el ingreso de personas en compañía de sus mascotas y que
              estos van a recibir un trato adecuado. Nuestro sitio web ha
              diseñado para nuestros usuarios, a un solo click, la posibilidad
              de interactuar con Google maps para consultar lugares que se
              encuentran adaptados con espacios y servicios que admitan el
              ingreso de mascotas.
              <br />
              <span>
                ¡¡¡No te cohíbas de planes excepcionales por pensar que tu
                mascota no será bienvenida!!!
              </span>
            </p>
          </div>
          <div className="petfriendly__img scl">
            <img src="/src/assets/img/petfriendly.png" alt="" />
          </div>
        </div>

        {/* <!-- Sección "Productos que van con tu mascota" --> */}
        <div className="shopinfo__grid container size">
          <div className="shopinfo__content">
            <h2>Productos que van con tu mascota</h2>
            <p>
              ¿Y qué tal si te atreves a explorar nuestro catálogo de productos
              especialmente diseñados para el confort de tu mascota? &#129300;
            </p>
            <Link
              to={`/productos`}
              className="btn__eyp--light btnshwanim--blur btn__hover--blur"
            >
              Conoce más
            </Link>
          </div>
          <div className="shopinfo__img scl">
            <img src="/src/assets/img/petshop.png" alt="" />
          </div>
        </div>

        {/* <!-- Sección "Tu compañero de por vida" --> */}
        <div className="adoptme__grid container size">
          <div className="adoptme__content">
            <h2>Tu compañero de por vida</h2>
            <p>
              Si eres de las personas que ama ayudar a los animales en condición
              de calle y que está en busca de un amigo fiel, te invitamos a
              conocer esta sección donde apoyados de la fundación
              <span>Adopta no compres</span>, buscamos a gente como tú, que esté
              en búsqueda de una mascota para su hogar.
            </p>
          </div>
          <div className="adoptme__img scl">
            <img src="/src/assets/img/adoptme.png" alt="" />
          </div>
        </div>
      </section>
    </>
  );
};
