export const LoginHeader = () => {
  return (
    <>
      <header>
        {/* <!-- Contenedor del título y el logotipo --> */}
        <div id="titulo" onclick="linkTo(null,null)">
          <div id="logoContainer" class="logo--flex">
            <img id="logo" src="/src/assets/img/logo.png" alt="" />
            <svg
              width="100"
              height="10"
              viewBox="0 0 354.99999999999994 42.500511538101215"
              class="css-1j8o68f"
            >
              <defs id="SvgjsDefs11147"></defs>
              <g
                transform="matrix(2.58588569707903,0,0,2.58588569707903,0.2771388718564083,-9.722252038458194)"
                fill="#caa6fb"
              >
                <path d="M10.01 8.467 l-5.2344 0 l0 3.2031 l4.6387 0 l0 2.5488 l-4.6387 0 l0 3.1934 l5.2344 0 l0 2.5879 l-8.1836 0 l0 -14.111 l8.1836 0 l0 2.5781 z M22.044935709635418 5.888999999999999 l2.9199 0 l0 14.111 l-3.3887 0 l-6.25 -10.088 l0 10.088 l-2.9199 0 l0 -14.111 l3.3496 0 l6.2891 10.029 l0 -10.029 z M30.14423704427083 20.19531 c-1.0938 0 -2.4219 -0.29297 -3.7305 -0.97656 l1.2402 -2.4121 c0.69336 0.48828 1.3672 0.75195 2.1387 0.75195 c1.1523 0 1.7383 -0.69336 1.7383 -2.3438 l0 -9.3262 l2.9297 0 l0 9.873 c0 2.8906 -1.7578 4.4336 -4.3164 4.4336 z M43.51717900390625 20.19531 c-4.1504 0 -7.2168 -2.832 -7.2168 -7.2559 c0 -4.4336 3.0664 -7.2461 7.2168 -7.2461 c4.1406 0 7.207 2.8125 7.207 7.2461 c0 4.4238 -3.0664 7.2559 -7.207 7.2559 z M43.51717900390625 17.5098 c2.4316 0 4.2969 -1.709 4.2969 -4.5703 c0 -2.8516 -1.8652 -4.5508 -4.2969 -4.5508 s-4.2969 1.6992 -4.2969 4.5508 c0 2.8613 1.8652 4.5703 4.2969 4.5703 z M63.38408658854166 5.888999999999999 l-4.6387 7.3535 l0 6.7578 l-2.9395 0 l0 -6.6895 l-4.668 -7.4219 l3.2422 0 l2.8809 4.8047 l2.8906 -4.8047 l3.2324 0 z M70.99540979817708 20.19531 c-4.1504 0 -7.2168 -2.832 -7.2168 -7.2559 c0 -4.4336 3.0664 -7.2461 7.2168 -7.2461 c4.1406 0 7.207 2.8125 7.207 7.2461 c0 4.4238 -3.0664 7.2559 -7.207 7.2559 z M70.99540979817708 17.5098 c2.4316 0 4.2969 -1.709 4.2969 -4.5703 c0 -2.8516 -1.8652 -4.5508 -4.2969 -4.5508 s-4.2969 1.6992 -4.2969 4.5508 c0 2.8613 1.8652 4.5703 4.2969 4.5703 z M85.5011173828125 20.19531 c-3.0957 0 -5.5176 -1.582 -5.5176 -5.1367 l0 -9.1699 l2.9297 0 l0 8.7695 c0 2.1484 1.1426 2.9492 2.5879 2.9492 c1.4551 0 2.6074 -0.81055 2.6074 -2.9492 l0 -8.7695 l2.9297 0 l0 9.1699 c0 3.5547 -2.4316 5.1367 -5.5371 5.1367 z M101.22747496744792 20 l-3.6719 -6.2109 l-0.84961 0 l0 6.2109 l-2.9297 0 l0 -14.111 l5.1172 0 c3.1934 0 4.541 1.8848 4.541 4.2188 c0 1.8945 -1.0742 3.125 -2.9883 3.5352 l4.248 6.3574 l-3.4668 0 z M96.70607496744792 8.32 l0 3.3691 l1.7285 0 c1.5625 0 2.1973 -0.66406 2.1973 -1.6797 c0 -1.0059 -0.63477 -1.6895 -2.1973 -1.6895 l-1.7285 0 z M112.09064505208335 5.888999999999999 c2.7637 0 4.4824 2.0508 4.4824 4.5605 c0 2.5684 -1.7188 4.4922 -4.4824 4.4922 l-2.9395 0 l0 5.0586 l-2.9297 0 l0 -14.111 l5.8691 0 z M111.60234505208334 12.4902 c1.4648 0 2.1484 -0.81055 2.1484 -2.0801 c0 -1.2207 -0.68359 -2.0703 -2.1484 -2.0703 l-2.4512 0 l0 4.1504 l2.4512 0 z M126.59660888671877 8.467 l-5.2344 0 l0 3.2031 l4.6387 0 l0 2.5488 l-4.6387 0 l0 3.1934 l5.2344 0 l0 2.5879 l-8.1836 0 l0 -14.111 l8.1836 0 l0 2.5781 z M137.17654459635418 5.888999999999999 l0 2.5781 l-3.3496 0 l0 11.533 l-2.9004 0 l0 -11.533 l-3.3691 0 l0 -2.5781 l9.6191 0 z"></path>
              </g>
            </svg>
          </div>
        </div>
        {/* <!-- Menú de navegación --> */}
        <div class="menu">
          {/* <!-- Botón de menú responsive --> */}
          <div class="sandwich-menu" onclick="toggleMenu()">
            &#9776;
          </div>
          {/* <!-- Sección de adopciones (condicional) --> */}
          {/* <% if(data.usuario != null) { %>
            <div class="menu-item">
                Adopciones
                <ul class="submenu">
                    <li onclick="linkTo('usuario','adopciones','adoptar/TODO/0/0')">Adoptar</li>
                    <li onclick="linkTo('usuario','adopciones','dar')">Dar en adopcion</li>
                </ul>
            </div>
        <% } %> */}
          {/* <!-- Sección de Lugares --> */}
          <div class="menu-item">
            Lugares
            <ul class="submenu">
              <li>
                <a
                  href="https://www.google.com/maps/search/pet+friendly/"
                  target="_blank"
                >
                  Pet Friendly
                </a>
              </li>
              <li onclick="linkTo('Pronto-Implementado')">Localización</li>
            </ul>
          </div>
          {/* <!-- Sección de Negocios --> */}
          <div class="menu-item">
            Negocios
            <ul class="submenu">
              <li onclick="linkTo('vender',null)">Vender</li>
              <li>
                Comprar
                <ul class="shop--submenu">
                  <li onclick="linkTo('productos','todo','0')">Todo</li>
                  <li onclick="linkTo('productos','juguetes','0')">Juguetes</li>
                  <li onclick="linkTo('productos','alimentos','0')">
                    Alimentos
                  </li>
                  <li onclick="linkTo('productos','accesorios','0')">
                    Accesorios
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          {/* <!-- Sección de Servicios --> */}
          <div class="menu-item">
            Servicios
            <ul class="submenu">
              <li>
                <a href="https://Digipets.com.co" target="_blank">
                  Veterinaria
                </a>
              </li>
              <li>
                Entrenamiento
                <ul class="vet--submenu">
                  <li onclick="linkTo('entrenamiento','ensenar')">Enseñar</li>
                  <li
                    class="menuc"
                    onclick="linkTo('entrenamiento','aprender')"
                  >
                    Aprender
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          {/* <!-- Sección de Cuenta (condicional) --> */}
          {/* <% if(data.usuario == null) { %>
            <div class="menu-item">
                Cuenta
                <ul class="submenu">
                    <li onclick="linkTo('cuenta','iniciar-sesion')">Iniciar</li>
                    <li onclick="linkTo('cuenta','registrarse')">Registrarse</li>
                </ul>
            </div>
        <% } else { %>
            <div class="menu-item">
                <!-- Nombre de usuario (extraído del objeto 'data') -->
                <% var usuario = data.usuario; %>
                <% var espacioIndex = usuario.indexOf(' '); %>
                <span><%= espacioIndex !== -1 ? usuario.substring(0, espacioIndex) : usuario %></span>
                <ul class="submenu">
                    <li onclick="linkTo('usuario', 'productos')">Productos</li>
                    <li onclick="linkTo('usuario', 'carrito')">Carrito</li>
                    <li onclick="linkTo('usuario', 'informacion')">Información</li>
                    <li onclick="linkTo('usuario', 'cerrar-sesion')">Salir</li>
                </ul>
            </div>
        <% } %> */}
          {/* <!-- Espacio adicional en el menú --> */}
          <div class="menu-item">
            <span></span>
            <ul class="submenu">
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
        {/* <!-- Script para la funcionalidad del menú --> */}
        <script src="/resources/js/header.js"></script>
      </header>
    </>
  );
};
