import React from 'react';
import { useNavigate } from 'react-router-dom';

export const SignUpModal = () => {
  const navigate = useNavigate(); // Utiliza useNavigate para obtener la función de navegación

  const handleSubmit = async event => {
    event.preventDefault();

    const formData = new FormData(event.target);
    const correo = formData.get('correo');
    const contrasenia = formData.get('contrasenia');
    const contrasenia2 = formData.get('contrasenia2');

    if (contrasenia !== contrasenia2) {
      alert('Las contraseñas no coinciden');
      return;
    }

    try {
      const response = await fetch(
        'https://apienjoy-production.up.railway.app/sign-up',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ correo, contrasenia }),
        }
      );

      const data = await response.json();
      console.log(data);

      if (data.correcto === true) {
        // Redirect to '/checkCode' if registration is successful
        navigate('/checkCode');
      }
    } catch (error) {
      console.error('Error al enviar la solicitud:', error);
    }
  };

  return (
    <section className="sign__flex container" style={{ marginTop: '8rem' }}>
      <form
        className="registerform"
        id="signup-form"
        onSubmit={handleSubmit}
        action="/registrar-usuario"
        method="post"
      >
        <h1>Regístrate</h1>
        <input
          id="_registercorreo"
          type="email"
          name="correo"
          placeholder="Correo"
          autoComplete="off"
          required
        />
        <input
          id="registercontrasenia"
          type="password"
          name="contrasenia"
          placeholder="Contraseña"
          autoComplete="off"
          required
        />
        <input
          id="registercontrasenia2"
          type="password"
          name="contrasenia2"
          placeholder="Confirma Tu Contraseña"
          autoComplete="off"
          required
        />
        <button id="submit-btn" type="submit" name="enviar">
          Enviar
        </button>
      </form>
    </section>
  );
};
