import React from 'react';
import { useNavigate } from 'react-router-dom';

export const Codverif = () => {
    const navigate = useNavigate(); // Utiliza useNavigate para obtener la función de navegación
    const handleSubmit = async (event) => {
        event.preventDefault(); // Evita que el formulario se envíe automáticamente

        const formData = new FormData(event.target);
        const correo = formData.get('correo');
        const codigo = parseInt(formData.get('codigo')); // Convierte el código a un número
        console.log(JSON.stringify({ correo, codigo }))
        try {
            const response = await fetch('https://apienjoy-production.up.railway.app/check-code', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ correo, codigo })
            });

            const data = await response.json();
            console.log(data); // Puedes hacer algo con la respuesta del servidor aquí
            if (data.correcto === true) {
                console.log("se registro correctamente");
                alert("registro completado");
                navigate('/')
            } else {
                console.log(data.error);
                alert(data.error);
            }
        } catch (error) {
            console.error('Error al enviar la solicitud:', error);
        }
    };

    return (
        <>
            <section className="sign__flex">
                {/* Formulario de registro de usuario */}
                <form
                    className="codform"
                    id="cod-form"
                    onSubmit={handleSubmit}
                    action="/registrar-usuario"
                    method="post"
                >
                    <h1>Confirma tu código</h1>

                    {/* Campo para ingresar el correo electrónico del usuario */}
                    <input
                        id="_registercorreo"
                        type="email"
                        name="correo"
                        placeholder="confirma tu correo"
                        autoComplete="on"
                        required
                    />

                    {/* Campo para ingresar el código de verificación como número */}
                    <input
                        id="registercontrasenia"
                        type="number" // Cambiado a type "number" para que se ingrese como número
                        name="codigo"
                        placeholder="Código de verificación"
                        autoComplete="off"
                        required
                    />

                    {/* Botón para enviar el formulario */}
                    <button id="submit-btn" type="submit" name="enviar">
                        Enviar
                    </button>
                </form>
            </section>
        </>
    );
};
