export const ShortFooter = () => {
  return (
    <footer class="footer">
      <div class="footercontainer">
        <div class="footer-content">
          <div class="footer-logo">
            <img
              src="/src/assets/img/usbbog_mag.png"
              alt="universidad de san buenaventura"
              style={{ height: '180px' }}
            />
          </div>
          <div class="footer-links">
            <ul>
              <li>
                <a href="#">Inicio</a>
              </li>
              <li>
                <a href="#">Nosotros</a>
              </li>
              <li>
                <a href="#">Servicios</a>
              </li>
              <li>
                <a href="#">Contacto</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-info">
          <p>&copy; 2023 EnjoyYourPet. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};
