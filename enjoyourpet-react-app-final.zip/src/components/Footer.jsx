export const Footer = ({ isLogin }) => {
  const classNames = isLogin ? 'footer footer-btm' : 'footer footer-bg';

  return (
    <>
      <footer className={classNames}>
        <div className="container footer__grid">
          {/* Logotipo de partners */}
          <div className="footer_partners footer_content">
            <a href="https://usbbog.edu.co" target="_blank">
              <img
                src="/src/assets/img/usbbog_mag.png"
                alt=""
                style={{ height: '180px' }}
              />
            </a>
          </div>

          {/* Sección "Lugares" */}
          <div className="footer__content">
            <h3>Lugares</h3>
            <nav>
              <a href="#">Petfriendly</a>
              <a href="#">Localización</a>
            </nav>
          </div>

          {/* Sección "Tienda" */}
          <div className="footer__content">
            <h3>Tienda</h3>
            <nav>
              <a href="vender">Vender</a>
              <a href="productos/todo/0">Comprar</a>
            </nav>
          </div>

          {/* Sección "Servicios" */}
          <div className="footer__content">
            <h3>Servicios</h3>
            <nav>
              <a href="https://digipets.com.co" target="_blank">
                Veterinaria
              </a>
              <a href="entrenamiento/aprender">Entrenamiento</a>
              {/* <a href="entrenamiento/ensenar">Enseñar</a> /} {/ Este enlace se encuentra comentado */}
            </nav>
          </div>

          {/* Sección "Enjoyourpet" */}
          <div className="footer__content">
            <h3>Enjoyourpet</h3>
            <nav>
              <a href="#">Nosotros</a>
              <a href="#">Logística</a>
            </nav>
          </div>
        </div>
        {/* Sección de redes sociales y derechos de autor */}
        <div className="footer__media">
          <p className="footer__copyright">
            Todos los derechos reservados © 2023
          </p>
          <div className="footer__icons">
            {/* Iconos de redes sociales */}
            <a href="#">
              <img src="resources/img/iconografia/facebook.png" alt="" />
            </a>
            <a href="#">
              <img src="resources/img/iconografia/instagram.png" alt="" />
            </a>
            <a href="#" className="iconsize">
              <img src="resources/img/iconografia/x.png" alt="" />
            </a>
            <a href="#" className="iconsize">
              <img src="resources/img/iconografia/threads.png" alt="" />
            </a>
            <a href="#">
              <img src="resources/img/iconografia/youtube.png" alt="" />
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};
