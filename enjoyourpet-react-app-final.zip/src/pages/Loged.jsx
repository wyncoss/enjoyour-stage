import { Header } from '../components/Header';
import { Carousel } from '../components/Carousel';
import { Footer } from '../components/Footer';
import { ShortFooter } from '../components/ShortFooter';

export const Loged = () => {
  return (
    <>
      <Carousel />
      <ShortFooter />
    </>
  );
};
