import { Footer } from '../components/Footer';
import { LoginHeader } from '../components/LoginHeader';
import { SignUpModal } from '../components/SignUpModal';

export const SignUpPage = () => {
  return (
    <>
      <LoginHeader />
      <SignUpModal />
      <Footer isLogin={true} />
    </>
  );
};
