export const ErrorPage = () => {
  return (
    <>
      <div className="container">
        <p className="center text-white">Estamos trabajando en ello. 😀</p>
      </div>
    </>
  );
};
