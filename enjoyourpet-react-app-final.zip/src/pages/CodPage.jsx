import { Header } from '../components/Header';
import { Codverif } from '../components/Codverif';
import { Footer } from '../components/Footer';

export const CodPage = () => {
  return (
    <>
      <Header />
      <Codverif />
      <Footer isLogin={false} />
    </>
  );
};
