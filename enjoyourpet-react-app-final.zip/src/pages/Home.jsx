import { Header } from '../components/Header';
import { Categories } from '../components/Categories';
import { Footer } from '../components/Footer';

export const Home = () => {
  return (
    <>
      <Header />
      <Categories />
      <Footer isLogin={false} />
    </>
  );
};
