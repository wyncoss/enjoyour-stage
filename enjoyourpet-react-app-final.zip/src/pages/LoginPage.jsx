import { Footer } from '../components/Footer';
import { LoginHeader } from '../components/LoginHeader';
import { LoginModal } from '../components/LoginModal';

export const LoginPage = () => {
  return (
    <>
      <LoginHeader />
      <LoginModal />
      <Footer isLogin={true} />
    </>
  );
};
