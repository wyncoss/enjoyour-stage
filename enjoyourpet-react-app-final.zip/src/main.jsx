import React from 'react';
import ReactDOM from 'react-dom/client';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import { Home } from './pages/Home';
import { LoginPage } from './pages/LoginPage';
import { Loged } from './pages/Loged';
import { CodPage } from './pages/CodPage';
import { SignUpPage } from './pages/SignUpPage';
import { ErrorPage } from './pages/ErrorPage';
import './assets/css/anim.css';
import './assets/css/body.css';
import './assets/css/carousel.css';
import './assets/css/footer.css';
import './assets/css/forms.css';
import './assets/css/globals.css';
import './assets/css/gradient.css';
import './assets/css/header.css';
import './assets/css/index.css';
import './assets/css/modal.css';
import './assets/css/normalize.css';
import './assets/css/productos.css';
import './assets/css/root.css';
import './assets/css/tablas.css';
import './assets/css/utilities.css';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
    errorElement: <ErrorPage />,
  },
  {
    path: '/inicia-sesion',
    element: <LoginPage />,
  },
  {
    path: '/registrarse',
    element: <SignUpPage />,
  },
  {
    path: '/loged',
    element: <Loged />,
  },
  {
    path: '/checkCode',
    element: <CodPage />
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
